var footerHtml = require('./footer.html');
$(function(){
    $('footer').html(footerHtml);
});
